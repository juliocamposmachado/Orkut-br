# 📜 Regras da Comunidade Orkut Fraternal

## I – Princípios Fundamentais

Esta comunidade existe para promover comunicação fraterna, ágil e construtiva, sem espaço para conteúdos degradantes, abusivos ou ilegais.

Nosso propósito é ser uma ferramenta de evolução humana, inspirada nos ensinamentos Rosacruzes, cultivando respeito, fraternidade e amor ao próximo.

## II – Proibição Absoluta
*(Base Legal: PL 2628/2022 e Estatuto da Criança e do Adolescente – ECA)*

É terminantemente proibido qualquer conteúdo que envolva:

- Pedofilia, pornografia infantil ou alusão sexual envolvendo menores de idade.
- Adultização de crianças (linguagem, imagens ou condutas que incentivem erotização precoce).
- Tentativas de contato, aliciamento ou manipulação de menores de idade.

**Todo e qualquer usuário que publicar, compartilhar ou insinuar tais práticas será:**
- Banido imediatamente e de forma definitiva;
- Denunciado automaticamente às autoridades competentes por meio de sistema de monitoramento e integração com órgãos de investigação.

## III – Conduta nas Postagens

- Respeite a dignidade humana em todas as interações.

**Proibidos conteúdos que promovam:**
- Ódio, discriminação, racismo, xenofobia, misoginia, homofobia, transfobia.
- Fake news, difamação, calúnia, assédio ou perseguição.
- Apologia a crimes, drogas ilícitas ou violência.

- Não publique conteúdos de caráter irrelevante, repetitivo ou spam.
- Evite discussões fúteis ou ofensivas – priorizamos objetividade, comunicação clara e construtiva.

## IV – Normas de Convivência Fraterna

- Trate todos os membros com respeito, mesmo em divergência de opiniões.
- Ao criticar, faça de forma construtiva e ética.
- Seja solidário: ofereça ajuda, incentive o diálogo e a cooperação.
- A comunidade não é espaço de ostentação ou vaidade, mas de aprendizado e evolução conjunta.

## V – Uso Profissional da Rede

Esta plataforma não é voltada para diversão superficial, mas sim para comunicação ágil, produtiva e profissional.

**Incentivamos o uso para:**
- Projetos de trabalho e colaboração.
- Estudos, pesquisa e difusão de conhecimento.
- Conexões humanas baseadas em ética e fraternidade.

## VI – Inspiração Rosacruz

Nossa comunidade se inspira no Código Rosacruz de Vida, cultivando:

- Respeito às diferenças, fraternidade e solidariedade.
- Valorização da vida, da natureza e do ser humano como templo da alma.
- Busca da verdade interior e da evolução espiritual, em harmonia com o próximo.

## VII – Disposições Finais

- O descumprimento das regras resultará em advertência, suspensão ou banimento.
- Casos graves serão imediatamente reportados às autoridades legais.
- **Nosso lema é: "Amor Fraternal, Comunicação Clara e Evolução Humana."**

## 📌 Mensagem Final

Esta comunidade não é apenas mais uma rede social. É um espaço de comunhão fraterna, ética e construtiva, alinhado ao propósito de crescimento humano e espiritual.

🙏 **PAZ PROFUNDA E ABRAÇOS FRATERNAIS.**

---

**Referência:** [Código Rosacruz de Vida - AMORC](https://amorc.org.br/codigo-rosacruz-de-vida)
