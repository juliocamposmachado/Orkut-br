// Alias para manter compatibilidade com importações
export * from './auth-context';
